var files =
[
    [ "csvstream.h", "csvstream_8h_source.html", null ],
    [ "dialog.h", "dialog_8h_source.html", null ],
    [ "mainengine.h", "mainengine_8h_source.html", null ],
    [ "mainwindow.h", "mainwindow_8h_source.html", null ],
    [ "mytablemodel.h", "mytablemodel_8h_source.html", null ]
];