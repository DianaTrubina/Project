var hierarchy =
[
    [ "QAbstractTableModel", null, [
      [ "MyTableModel", "class_my_table_model.html", null ]
    ] ],
    [ "QDialog", null, [
      [ "Dialog", "class_dialog.html", null ]
    ] ],
    [ "QMainWindow", null, [
      [ "MainWindow", "class_main_window.html", null ]
    ] ],
    [ "QObject", null, [
      [ "CsvStream", "class_csv_stream.html", null ],
      [ "MainEngine", "class_main_engine.html", null ]
    ] ]
];