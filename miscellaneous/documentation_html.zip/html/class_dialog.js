var class_dialog =
[
    [ "Dialog", "class_dialog.html#acfa2063f9f962d394c6a645b6e7e08d8", null ]
];