var class_main_window =
[
    [ "MainWindow", "class_main_window.html#a8b244be8b7b7db1b08de2a2acb9409db", null ],
    [ "getConstCsvModel", "class_main_window.html#a155ed70ed026d56713867e28daa4abdb", null ],
    [ "whatCurrentFile", "class_main_window.html#a91214184f2730045f7e72487b381ddb1", null ]
];